﻿var SOURCE_URL = "http://pilotlight.net/exsource/rib/3dapp/";
var SOURCE_IMG_URL = "http://pilotlight.net/exsource/rib/3dapp/sources/";
var WORDS_JSON = "wordlist.json";

var WORDS_KEY = "wordlist";
var PICTURES_KEY = "pictures";