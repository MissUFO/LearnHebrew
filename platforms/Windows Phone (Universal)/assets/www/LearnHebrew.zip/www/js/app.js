
angular.module('starter', ['ionic', 'starter.controllers'])

.run(function ($ionicPlatform, $ionicPopup, wordsService) {
    $ionicPlatform.ready(function () {

        wordsService.getData().then(function (words) {
            window.localStorage.setItem(WORDS_KEY, JSON.stringify(words.data.wordlist));

            if (words == undefined || words == null) {

                var alertPopup = $ionicPopup.alert({
                    title: 'Internet connection is required!',
                    template: 'This application requires an Internet connection to access a new word from the dictionary.'
                });
                alertPopup.then(function (res) {

                });
            }

        });

    });
})

.config([
  '$compileProvider',
  function ($compileProvider) {
      $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|mailto|file|ghttps?|ms-appx|x-wmapp0):/);
  }
])

.config(function ($stateProvider, $urlRouterProvider) {
    $stateProvider

    .state('app', {
        url: "/app",
        abstract: true,
        templateUrl: "templates/menu.html",
        controller: 'AppCtrl'
    })

    .state('app.home', {
        url: "/home",
        views: {
            'menuContent': {
                templateUrl: "templates/home.html",
                controller: 'HomeCtrl'
            }
        }
    })

    .state('app.about', {
        url: "/about",
        views: {
            'menuContent': {
                templateUrl: "templates/about.html"
            }
        }
    })
      .state('app.words-index', {
          url: "/words-index",
          views: {
              'menuContent': {
                  templateUrl: "templates/words-index.html",
                  controller: 'WordsIndexCtrl'
              }
          }
      })

    .state('app.word-conventional', {
        url: "/words-index/word-conventional/:wordId",
        views: {
            'menuContent': {
                templateUrl: "templates/word-conventional.html",
                controller: 'WordConventionalCtrl'
            }
        }
    })

    .state('app.word-numeric', {
        url: "/words-index/word-numeric/:wordId",
        views: {
            'menuContent': {
                templateUrl: "templates/word-numeric.html",
                controller: 'WordConventionalCtrl'
            }
        }
    })

    .state('app.word-pictorial', {
        url: "/words-index/word-pictorial/:wordId",
        views: {
            'menuContent': {
                templateUrl: "templates/word-pictorial.html",
                controller: 'WordConventionalCtrl'
            }
        }
    });

    // if none of the above states are matched, use this as the fallback
    $urlRouterProvider.otherwise('/app/home');
})

.factory('wordsService', function ($http) {
        var words = [];

        return {
            getData: function () {
               
                return $http.get(SOURCE_URL + WORDS_JSON).then(function (response) {
                    words = response;
                    return words;
                });
            }
        }
})

.factory('singleWordService', function ($http) {
        
    var word;
    var src;

        return {
            getData: function (id) {
              
                return $http.get(SOURCE_URL + id + ".json").then(function (response) {
                    word = response.data;
                    return word;
                });
            },
            cacheImg: function (url) {

                //$ImageCacheFactory.Cache(url); 
                //.then(function () {
                //    console.log("Images done loading!");
                //}, function (failed) {
                //    console.log("An image filed: " + failed);
                //});
            }
        }
    })

.factory('logicService', function ($q) {

    return {

        findAll: function(Words) {

            var deferred = $q.defer();
            deferred.resolve(Words);
            return deferred.promise;
        },

        findByName: function(Words, searchKey) {

            var deferred = $q.defer();
            var results = Words.filter(function (element) {
                var title = element.name;
                return title.toLowerCase().indexOf(searchKey.toLowerCase()) > -1;
            });

            deferred.resolve(results);
            return deferred.promise;
        },

        findByLetter: function (Words, searchKey) {

            var deferred = $q.defer();
            var results = Words.filter(function (element) {
                var title = element.name.toLowerCase();
                return (title.substr(0, 1).toLowerCase() == searchKey.toLowerCase());
            });

            deferred.resolve(results);
            return deferred.promise;
        }
    }
})
.directive('ionSearch', function () {
    return {
        restrict: 'E',
        replace: true,
        scope: {
            getData: '&source',
            model: '=?',
            search: '=?filter'
        },
        link: function (scope, element, attrs) {
            attrs.minLength = attrs.minLength || 0;
            scope.placeholder = attrs.placeholder || '';
            scope.search = { value: '' };

            if (attrs.class)
                element.addClass(attrs.class);
                        
            if (attrs.source) {
                scope.$watch('search.value', function (newValue, oldValue) {
                    if (newValue.length >= attrs.minLength) {
                        scope.getData({ str: newValue }).then(function (results) {
                            scope.model = results;
                        });
                    } else {
                        scope.model = [];
                    }
                });
            }

            scope.clearSearch = function () {
                scope.search.value = '';
            };
            
            scope.showAllWords = function ()
            {               
                scope.$parent.showAllWords();
            };           
        },
        template: '<div class="item-input-wrapper" >' +
                    '<table><tr><td class="first-cell"><i class="icon ion-android-search"></i>' +
                    '</td><td class="second-cell"><input name="searchKey" id="searchKey" type="search" ng-click="clearSearch()" placeholder="{{placeholder}}" ng-model="search.value"  >' +
                    '</td><td width="10px;"><div id="allDictionary" name="allDictionary" class="book-dark-button" ng-click="showAllWords()" ><img src="images/book-dark-icon.png"></div>' +
                  '</td></tr><table></div>'
    };
  
});


