angular.module('starter.controllers', [])

.controller('AppCtrl', function ($scope, $ionicModal, $timeout) {

})

.controller('HomeCtrl', function ($scope, $window, $state) {

    $scope.btnClick = function () {

        $window.location.href = '#/app/words-index';

    };
})

.controller('WordsIndexCtrl', function ($scope, $ionicHistory, wordsService, logicService) {

    $scope.characters = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "Y", "Z"];

    $scope.words = [];
    $scope.allwords = [];
    $scope.currentSearchValue = "";

    if (window.localStorage.getItem(WORDS_KEY) != undefined) {

        $scope.allwords = JSON.parse(window.localStorage.getItem(WORDS_KEY));
        $scope.words = $scope.allwords;

    }
    if ($scope.allwords == null) {

        wordsService.getData().then(function (words) {
            $scope.allwords = words.data.wordlist;
            window.localStorage.setItem(WORDS_KEY, JSON.stringify($scope.allwords));
        }).then(function () {
            logicService.findAll($scope.allwords).then(function (Words) {
                $scope.words = Words;
            });

            if ($scope.allwords == null) {
                $ionicHistory.goBack();
            }
        });
    }


    $scope.getWorldByName = function (str) {

        $scope.currentSearchValue = str;

        logicService.findByName($scope.allwords, str).then(function (Words) {
            $scope.words = Words;
        });

    };

    $scope.getWorldByLetter = function (str) {

        $scope.currentSearchValue = str;
        document.getElementById("searchKey").value = $scope.currentSearchValue;

        logicService.findByLetter($scope.allwords, str).then(function (Words) {
            $scope.words = Words;
        });

    };

    $scope.showAllWords = function () {

        $scope.currentSearchValue = "";
        document.getElementById("searchKey").value = $scope.currentSearchValue;

        $scope.words = $scope.allwords;
    };

})

.controller('WordConventionalCtrl', function ($scope, $ionicHistory, $stateParams, singleWordService) {

    $scope.word = null;
    $scope.id = $stateParams.wordId;

    $scope.getLetterImg = function (objects, key) {

        var source_item = objects.sources.filter(function (element) {
            var l = element.letter.toLowerCase();
            return (l.toLowerCase() == key.toLowerCase());
        });
        
        if (source_item != undefined && source_item.length > 0) {
            var url = SOURCE_IMG_URL + source_item[0].letterGraphic;
            //singleWordService.cacheImg(url);

            return url;
        }
        else
            return "";
    }

    $scope.getPictureImg = function (objects, key) {

        var source_item = objects.sources.filter(function (element) {
            var l = element.letter.toLowerCase();
            return (l.toLowerCase() == key.toLowerCase());
        });
                
        if (source_item != undefined && source_item.length > 0) {
            var url = SOURCE_IMG_URL + source_item[0].letterPicture;
            //singleWordService.cacheImg(url);

            return url;
        }
        else
            return "";
    }

    if ($scope.word == null) {
        singleWordService.getData($scope.id).then(function (word) {
            if (word != null && word != undefined) {
                $scope.word = word;
                window.localStorage.setItem($scope.id, JSON.stringify($scope.word));
            }
        });
    }

    if ($scope.word == null) {
        if (window.localStorage.getItem($scope.id) != undefined) {
            $scope.word = JSON.parse(window.localStorage.getItem($scope.id));
        }
    }

    if ($scope.word == null) {
        $ionicHistory.goBack();
    }

});
